Beads - a computer music and sound art library for Java. 
http://www.beadsproject.net.

This is the Beads Library. See library for jar files, doc for JavaDoc files or import this folder into Eclipse where you can run the tutorial code. Enjoy!