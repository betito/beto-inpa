README for JSyn
Copyright (C) 1997-2011 Phil Burk, Mobileer Inc
All Rights Reserved

JSyn is an Audio Synthesis toolbox for Java.

--------------- License ---------------------------

Please read the license at:
  http://www.softsynth.com/jsyn/developers/jsyn_sdk_license.txt

--------------- Installation -------------------------

For HTML docs on how to install and use JSyn visit:
  http://www.softsynth.com/jsyn/docs/

If you encounter ANY bugs, or have any suggestions please let me know.

Thank you,
Phil Burk
Mobileer Inc
